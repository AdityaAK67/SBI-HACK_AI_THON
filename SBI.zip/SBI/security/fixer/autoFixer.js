// const fs = require('fs');
// const path = require('path');
// const OpenAI = require('openai');

// // ✅ Direct API key (make sure to protect this in production)
// const openai = new OpenAI({
//   apiKey: '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',
// });

// const filePath = process.argv[2];
// const lineNumber = parseInt(process.argv[3]);

// if (!filePath || isNaN(lineNumber)) {
//   console.error('❌ Usage: node autoFixer.js <filePath> <lineNumber>');
//   process.exit(1);
// }

// (async () => {
//   try {
//     const code = fs.readFileSync(filePath, 'utf-8');
//     const lines = code.split('\n');

//     const targetLine = lines[lineNumber - 1];
//     if (!targetLine) throw new Error(`Line ${lineNumber} not found.`);

//     console.log(`🧠 Original Line: ${targetLine}`);

//     const prompt = `You are a secure code assistant. Fix the following line of code to eliminate vulnerabilities (like XSS, injection, unsafe APIs, etc). Return only the fixed line of code.\n\nLine:\n${targetLine}`;

//     const response = await openai.chat.completions.create({
//       model: 'gpt-4',
//       messages: [{ role: 'user', content: prompt }],
//       temperature: 0.2,
//     });

//     const fixedLine = response.choices[0].message.content.trim();
//     lines[lineNumber - 1] = fixedLine;
//     fs.writeFileSync(filePath, lines.join('\n'), 'utf-8');

//     console.log(`✅ Fixed Line:\n${fixedLine}`);
//   } catch (err) {
//     console.error(`❌ AutoFix failed: ${err.message}`);
//     process.exit(1);
//   }
// })();



const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const OpenAI = require('openai');

// ✅ Securely initialize OpenAI API
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || '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',
});

// ✅ Parse CLI args
const args = process.argv.slice(2);

(async () => {
  try {
    if (args[0] === '--fix-all') {
      const folderPath = args[1];
      if (!folderPath) throw new Error('❌ Folder path required after --fix-all');

      const resolvedFolder = path.resolve(folderPath);

      console.log(`🔍 Running ESLint fix on: ${resolvedFolder}`);

      exec(`eslint "${resolvedFolder}" --fix`, async (err, stdout, stderr) => {
        if (err) {
          console.error(`❌ ESLint failed: ${stderr || err.message}`);
          console.log('🧠 Attempting AI-based fix as fallback...');

          const files = fs.readdirSync(resolvedFolder).filter(f => f.endsWith('.js') || f.endsWith('.ts'));

          for (const file of files) {
            const filePath = path.join(resolvedFolder, file);
            const code = fs.readFileSync(filePath, 'utf-8');

            const prompt = `
You are a secure code assistant.
Fix all security vulnerabilities in the following code — such as SQL injection, XSS, insecure APIs, command injection, hardcoded credentials, and other OWASP Top 10 or SANS Top 25 issues.
Return the entire secure and corrected version of the code without explanation.

Code:
\`\`\`
${code}
\`\`\`
`;

            const response = await openai.chat.completions.create({
              model: 'gpt-4',
              messages: [{ role: 'user', content: prompt }],
              temperature: 0.2,
            });

            const fixedCode = response.choices[0].message.content
              .replace(/^```[\s\S]*?\n/, '')
              .replace(/```$/, '');

            fs.writeFileSync(filePath, fixedCode, 'utf-8');
            console.log(`✅ AI-fixed: ${file}`);
          }

          console.log('✅ AutoFix completed using AI.');
          process.exit(0);
        } else {
          console.log('✅ ESLint fix completed.');
          console.log(stdout);
          process.exit(0);
        }
      });

    } else {
      // 📄 Fix specific file or line
      const filePath = args[0];
      const lineNumber = args[1] ? parseInt(args[1]) : null;

      if (!filePath) throw new Error('❌ Usage: node autoFixer.js <filePath> [lineNumber]');

      const resolvedFilePath = path.resolve(filePath);
      const code = fs.readFileSync(resolvedFilePath, 'utf-8');
      const lines = code.split('\n');

      if (lineNumber && !isNaN(lineNumber)) {
        const targetLine = lines[lineNumber - 1];
        if (!targetLine) throw new Error(`❌ Line ${lineNumber} not found.`);

        console.log(`🧠 Fixing line ${lineNumber}: ${targetLine}`);

        const prompt = `You are a secure code assistant. Fix this line to eliminate security vulnerabilities:\n${targetLine}`;

        const response = await openai.chat.completions.create({
          model: 'gpt-4',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.2,
        });

        const fixedLine = response.choices[0].message.content.trim();
        lines[lineNumber - 1] = fixedLine;
        fs.writeFileSync(resolvedFilePath, lines.join('\n'), 'utf-8');

        console.log(`✅ Fixed Line ${lineNumber}:\n${fixedLine}`);
      } else {
        console.log('📦 Fixing full file...');

        const prompt = `
You are a secure code assistant.
Fix all vulnerabilities in the code below. Return only the corrected version.

\`\`\`
${code}
\`\`\`
`;

        const response = await openai.chat.completions.create({
          model: 'gpt-4',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.2,
        });

        const fixedCode = response.choices[0].message.content
          .replace(/^```[\s\S]*?\n/, '')
          .replace(/```$/, '');

        fs.writeFileSync(resolvedFilePath, fixedCode, 'utf-8');
        console.log('✅ File successfully auto-fixed!');
      }
    }
  } catch (err) {
    console.error(`❌ AutoFix failed: ${err.message}`);
    process.exit(1);
  }
})();
