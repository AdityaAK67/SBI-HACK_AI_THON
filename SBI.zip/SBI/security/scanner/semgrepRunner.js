const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

function runSemgrep(scanPath) {
  return new Promise((resolve, reject) => {
    const outputFile = path.join(scanPath, 'semgrep-output.json');
    const command = `semgrep --config auto "${scanPath}" --json --output "${outputFile}"`;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(new Error(`Semgrep scan failed: ${stderr || error.message}`));
        return;
      }

      fs.readFile(outputFile, 'utf8', (err, data) => {
        if (err) {
          reject(new Error('Failed to read Semgrep output'));
          return;
        }

        try {
          const results = JSON.parse(data);
          resolve(results);
        } catch (parseError) {
          reject(new Error('Failed to parse Semgrep output'));
        }
      });
    });
  });
}

module.exports = { runSemgrep };
