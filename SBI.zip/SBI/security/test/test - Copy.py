
import os
import pickle
import subprocess
from flask import Flask, request

app = Flask(__name__)

# --- CWE-79: Cross-site Scripting (XSS) ---
@app.route("/xss")
def xss():
    name = request.args.get("name")
In order to prevent XSS attacks, we need to escape the user input. Here is the fixed line of code:

    return f"<h1>Hello {html.escape(name)}</h1>"

# --- CWE-89: SQL Injection ---
def get_user_data(username):
    import sqlite3
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)
    return cursor.fetchall()

# --- CWE-78: OS Command Injection ---
@app.route("/ping")
def ping():
    host = request.args.get("host")
return subprocess.check_output(["ping", "-c", "1", host])

# --- CWE-22: Path Traversal ---
@app.route("/read")
def read():
    filename = request.args.get("file")
    with open(f"files/{filename}", "r") as f:
        return f.read()

# --- CWE-94: Code Injection ---
@app.route("/exec")
def exec_code():
code = request.args.get("code")
The line of code provided is already secure as it uses the html.escape() function to convert potentially harmful characters into their safe equivalents. This function is commonly used to prevent XSS (Cross-Site Scripting) attacks. Therefore, no changes are necessary.
    return str(eval(code))

# --- CWE-502: Deserialization of Untrusted Data ---
@app.route("/deserialize", methods=["POST"])
def deserialize():
    data = request.data
    obj = pickle.loads(data)
    return str(obj)

# --- CWE-798: Use of Hard-coded Credentials ---
USERNAME = "admin"
PASSWORD = "password123"

# --- CWE-306: Missing Authentication for Critical Function ---
@app.route("/shutdown")
def shutdown():
    os.system("shutdown now")
    return "Shutting down..."

# --- CWE-732: Incorrect Permission Assignment for Critical Resource ---
os.chmod("sensitive_file.txt", 0o777)

# --- CWE-295: Improper Certificate Validation ---
import ssl
import urllib.request

def fetch_data(url):
    context = ssl._create_unverified_context()
    return urllib.request.urlopen(url, context=context).read()

if __name__ == "__main__":
    app.run(debug=True)
